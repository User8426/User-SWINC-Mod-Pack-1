# SoftwareInc_E-DrinkMod
A mod for Software Inc A11. This mod was created off a idea from the official Discord.
To run this mod, place the folder with all files inside in the mods folder inside of the folder where game data/installation folder for Software Inc is stored.

Notes - If alcohol is added to a E-Drink product, you could have legal trouble in game.
