# SoftwareInc_AI-Software-Mod
A mod for the game Software Inc providing a new type of software, AI. AI can be a virtual assistant, or a bot for a game or even Discord (not literally).
To install, place the folder containing all of the folders + License + This text document inside of the mods folder inside of where Software Inc is installed.

Special thanks to
MattA - Fixing some bugs and adding fix via pull request.
