# Software-Inc-Virus-Mod
Mod for SWINC. Allows viruses to be made.
Place this folder in the Software Inc Mods folder to be able to access this mod

What does this mod do?
Adds two new software types: Viruses and Cryptominers. Instead of having people pay for it, they pay to have it removed from their computer, but if the law ever finds out about it, they will take you to court and send out a fix for all users.

Image Credits

https://pixabay.com/vectors/usb-port-usb-drive-universal-24859/
https://www.premiumusb.com/blog/whats-inside-a-usb-drive
https://pixabay.com/vectors/bottle-pet-drink-plastic-159119/
https://www.google.com/url?sa=i&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FTest_point&psig=AOvVaw3E8horBLtzVvMzmY6LboBM&ust=1616692143695000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCODGldq1ye8CFQAAAAAdAAAAABAE
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.wikihow.com%2FFormat-a-Write%25E2%2580%2593Protected-Pen-Drive&psig=AOvVaw0AAmDsWCgSmj9HgLjx_e3k&ust=1616692228883000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCMjJ74K2ye8CFQAAAAAdAAAAABAG
https://www.google.com/url?sa=i&url=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3ACircuit_board_from_a_USB_3.0_external_2.5-inch_HDD_enclosure.jpg&psig=AOvVaw3Pllwi2dlw0WpGUce3eN-z&ust=1616692315639000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCND4mKy2ye8CFQAAAAAdAAAAABAL
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.electronicsweekly.com%2Fnews%2Fproducts%2Femech-enclosures%2Fsmall-enclosures-for-usb-dongles-2016-06%2F&psig=AOvVaw1_vgtv6RIZ3wpgc8PukFbC&ust=1616692486227000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPCfx_22ye8CFQAAAAAdAAAAABAE
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.aeroexpo.online%2Fprod%2Ftoray-advanced-composites%2Fproduct-172149-20646.html&psig=AOvVaw0sLzrXdi-6Z1UE_5154IA8&ust=1616776851263000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCKCTi6Hxy-8CFQAAAAAdAAAAABAE
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.amazon.co.uk%2FEpoxy-Primer-Binder-2-component-Coverings%2Fdp%2FB089QQRRH5&psig=AOvVaw3HfZlvwxID1cHDTGscUXTQ&ust=1616776849143000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCOi6-Z_xy-8CFQAAAAAdAAAAABAE

Patch Notes

V1.1 - Added BadUSB software type, however it is not complete.
V1.2 - BadUSB software type is now working and is in a more complete state.
