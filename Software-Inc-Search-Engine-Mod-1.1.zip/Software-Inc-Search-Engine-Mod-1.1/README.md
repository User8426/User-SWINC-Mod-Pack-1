# Software-Inc-Search-Engine-Mod
Adds a new software type, search engines to the game. 

This is my 4th mod, search engines. Search engines are a new software type that focus on server usage and ads, making it harder to use more features near the start of the game, so potential interest has to be built up, over time.

Thanks to MattA for suggesting some fixes for some bugs
